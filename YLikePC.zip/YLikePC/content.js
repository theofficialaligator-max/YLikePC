document.addEventListener("dblclick", (e) => {
    // Only run on YouTube Shorts
    if (!location.pathname.startsWith("/shorts/")) return;

    // Find the Shorts video element
    const video = document.querySelector("video");

    if (!video) return;

    // Get video position
    const rect = video.getBoundingClientRect();

    // Make sure the double click happened inside the video
    if (
        e.clientX < rect.left ||
        e.clientX > rect.right ||
        e.clientY < rect.top ||
        e.clientY > rect.bottom
    ) {
        return;
    }

    const likeButton = document.querySelector(
        'button[aria-label*="like"], button[aria-label*="Like"]'
    );

    if (!likeButton) return;

    const isLiked =
        likeButton.getAttribute("aria-pressed") === "true";

    if (!isLiked) {
        likeButton.click();
    }

    const heart = document.createElement("div");

    const rotation = Math.floor(Math.random() * 61) - 30;

    heart.textContent = "❤️";
    heart.style.position = "fixed";
    heart.style.left = `${e.clientX}px`;
    heart.style.top = `${e.clientY}px`;
    heart.style.transform =
        `translate(-50%, -50%) rotate(${rotation}deg)`;
    heart.style.fontSize = "100px";
    heart.style.pointerEvents = "none";
    heart.style.zIndex = "999999";

    heart.animate(
        [
            {
                transform:
                    `translate(-50%, -50%) rotate(${rotation}deg) scale(0.8)`,
                opacity: 0
            },
            {
                transform:
                    `translate(-50%, -70%) rotate(${rotation}deg) scale(1.2)`,
                opacity: 1
            },
            {
                transform:
                    `translate(-50%, -120%) rotate(${rotation}deg) scale(1)`,
                opacity: 0
            }
        ],
        {
            duration: 800,
            easing: "ease-out"
        }
    );

    document.body.appendChild(heart);

    setTimeout(() => {
        heart.remove();
    }, 800);
});